'use client';

import {
  createContext,
  useState,
  useContext,
  useCallback,
  useMemo,
  ReactNode,
} from 'react';

interface AuthContextType {
  token: string | null;
  user: null;
  login: (token: string, user: unknown) => void;
  logout: () => void;
  refresh: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [token, setToken] = useState<string | null>(null);

  const login = useCallback((_newToken: string, _newUser: unknown) => {
    // No-op in local-only mode
  }, []);

  const logout = useCallback(async () => {
    // No-op in local-only mode
  }, []);

  const refresh = useCallback(async () => {
    // No-op in local-only mode
  }, []);

  const value = useMemo(
    () => ({ token, user: null, login, logout, refresh }),
    [token, login, logout, refresh],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
