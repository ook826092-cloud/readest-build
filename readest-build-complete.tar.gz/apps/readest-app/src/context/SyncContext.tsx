'use client';

import React, { createContext, useContext, useMemo } from 'react';

class NoopSyncClient {
  async pullChanges(): Promise<null> {
    return null;
  }
  async pushChanges(): Promise<null> {
    return null;
  }
}

const syncClient = new NoopSyncClient();

interface SyncContextType {
  syncClient: NoopSyncClient;
}

const SyncContext = createContext<SyncContextType>({ syncClient });

export const SyncProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const value = useMemo(() => ({ syncClient }), []);
  return <SyncContext.Provider value={value}>{children}</SyncContext.Provider>;
};

export const useSyncContext = () => useContext(SyncContext);
