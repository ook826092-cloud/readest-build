import { TranslationFunc } from '@/hooks/useTranslation';

// Update checking is completely disabled in local-only mode.

export const checkForAppUpdates = async (
  _: TranslationFunc,
  _isAutoCheck = true,
): Promise<boolean> => {
  return false;
};

export const setLastShownReleaseNotesVersion = (_version: string) => {
  // No-op
};

export const getLastShownReleaseNotesVersion = () => {
  return '';
};

export const checkAppReleaseNotes = async (_isAutoCheck = true) => {
  return false;
};
