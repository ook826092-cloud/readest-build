export class QueryResult {
  constructor() {
    this.rowsAffected = 0;
    this.lastInsertId = 0;
  }
}

export class Database {
  static async load(path) {
    return new Database();
  }
  async execute(sql, params) {
    return { rowsAffected: 0, lastInsertId: 0 };
  }
  async select(sql, params) {
    return [];
  }
}
