'use client';

import { ReactNode } from 'react';

// PostHog is completely disabled in local-only mode.
// All capture/identify calls are no-ops.

export const CSPostHogProvider = ({ children }: { children: ReactNode }) => {
  return <>{children}</>;
};
